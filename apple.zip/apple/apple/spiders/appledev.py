## Import require Packages

from scrapy.spider import BaseSpider
from scrapy.selector import HtmlXPathSelector
from apple.items import AppleItem
from scrapy.http.request import Request
from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.contrib.spiders import CSVFeedSpider
from datetime import datetime
from urlparse import urljoin
import time
import re


class MySpider(BaseSpider):
  name = "applevideo"
  allowed_domains = ["apple.com"]
  start_urls =['https://developer.apple.com/videos/']
  
  def parse(self, response):
      item = AppleItem()
      years = ['2012','2013','2014','2015','2016']
      for year in years:
        year = int(year)
        item['Year'] = year
        time.sleep(20)
        request = Request(("https://developer.apple.com/videos/wwdc%d"%year), callback=self.jobdetail)

        request.meta['item']=item
        yield request
        
  def jobdetail(self, response):
        item=response.meta['item']
        alvideo = response.xpath('.//*[@class="collection-item "]')
        for video in alvideo:
          try:
            item['HDVideo'] = video.xpath(".//section[@class='col-30 no-padding-top no-padding-bottom']/a/@href").extract()
            item['HDVideo'] = ''.join(map(str, item['HDVideo']))
            item['HDVideo'] = 'https://developer.apple.com'+item['HDVideo']
          except:
            item['HDVideo'] = ''
          try:
            item['Title'] = video.xpath(".//section[@class='col-70 no-padding-top no-padding-bottom']/a/h5/text()").extract()
          except:
            item['Title'] = video.xpath(".//section[@class='col-80 no-padding-top no-padding-bottom']/a/h5/text()").extract()
          try:
            item['SessionNumber'] = video.xpath(".//span[contains(.,'Session')]/text()").extract()[0]
            item['SessionNumber'] = ''.join(map(str, item['SessionNumber']))
            item['SessionNumber'] =  item['SessionNumber'].replace('Session','')
          except:
            item['SessionNumber'] = ''

          try:
            item['PresentationSlides'] = video.xpath(".//section[@class='col-30 no-padding-top no-padding-bottom']/a/img/@src").extract()
          except:
            item['PresentationSlides'] = ''

          try:
              item['SDVideo'] = video.xpath(".//section[@class='class='col-70 no-padding-top no-padding-bottom']/a/@href").extract()
              item['SDVideo'] = ''.join(map(str, item['SDVideo']))
              item['SDVideo'] = 'https://developer.apple.com'+item['SDVideo']
          except:
              item['SDVideo'] = video.xpath(".//section[@class='col-80 no-padding-top no-padding-bottom']/a/@href").extract()
              item['SDVideo'] = ''.join(map(str, item['SDVideo']))
              item['SDVideo'] = 'https://developer.apple.com'+item['SDVideo']
        return item          


    

      

      
